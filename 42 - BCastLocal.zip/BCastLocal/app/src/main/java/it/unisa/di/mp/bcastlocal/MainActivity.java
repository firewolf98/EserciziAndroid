package it.unisa.di.mp.bcastlocal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
	BroadcastReceiver receiver;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		setBroadcastReceiver();
	}
	
	public void sendBroadcast(View v) {
		sendBroadcast(new Intent("it.unisa.di.mp.bcastlocal.my_string"));
	}
	
	private void setBroadcastReceiver() {
		IntentFilter intentFilter = 
				new IntentFilter("it.unisa.di.mp.bcastlocal.my_string");

		receiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				Log.d("DEBUG", "dynamically registered receiver");
				Toast.makeText(context, 
						   "Intent received by the dynamically registered receiver", 
						   Toast.LENGTH_LONG).show();

			}
		};
		
		registerReceiver(receiver, intentFilter);
	}


}

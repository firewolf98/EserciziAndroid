package it.unisa.di.mp.multiactivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class Activity2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
    }

    public void lanciaActivity(View v) {
        Intent i = new Intent(getApplicationContext(),Activity3.class);
        startActivity(i);
    }
}

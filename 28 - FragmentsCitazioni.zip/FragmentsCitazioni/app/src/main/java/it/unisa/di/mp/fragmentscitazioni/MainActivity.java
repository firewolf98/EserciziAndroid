package it.unisa.di.mp.fragmentscitazioni;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements FragmentAutori.Communicator {

    FragmentAutori fragmentAutori;
    FragmentCitazioni fragmentCitazioni;
    FragmentManager fm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fm = getFragmentManager();

        fragmentAutori = (FragmentAutori) fm.findFragmentById(R.id.fragmentAutori);
        fragmentAutori.setCommunicator(this);

    }

    @Override
    public void respond(int index) {
        fragmentCitazioni = (FragmentCitazioni) fm.findFragmentById(R.id.fragmentCitazioni);

        if (fragmentCitazioni!=null && fragmentCitazioni.isVisible()) {
            fragmentCitazioni.mostraCitazione(index);
        }
        else {
            Intent i = new Intent(this, PortraitActivity.class);
            i.putExtra("index",index);
            startActivity(i);
        }
    }
}

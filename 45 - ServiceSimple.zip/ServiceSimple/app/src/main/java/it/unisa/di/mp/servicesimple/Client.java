package it.unisa.di.mp.servicesimple;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;

public class Client extends ActionBarActivity {
	Intent musicPlayService;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		musicPlayService = new Intent(getApplicationContext(), MusicPlayService.class);
	}
	
	public void startService(View v) {
		Log.d("DEBUG","Starting Music Service");
		startService(musicPlayService);
	}

	public void stopService(View v) {
		Log.d("DEBUG","Stopping Music Service");
		stopService(musicPlayService);
	}

}

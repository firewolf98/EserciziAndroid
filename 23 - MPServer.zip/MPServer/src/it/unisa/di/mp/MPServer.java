package it.unisa.di.mp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.*;
import java.io.*;

public class MPServer {
	
	private static int delay = 0;

	private static void log(String message) {
		System.out.println("MPServer: "+message);
	}

	private static void print(String message) {
		System.out.println("MPServer: "+message);
	}

	public static void main(String[] args) throws Exception {
		//Start server	
		print("MP server\n");
		print("riceve una linea (stringa str)");
		print("   se la str e' [sordi|neruda|einstein|manzoni|leopardi] risponde con la citazione");
		print("   altrimenti, legge il file il cui nome e' <str>, e spedisce prima");
		print("   il conteggio dei byte e poi il contenuto");
		print("Uso: MPserer <port> [<d>]");
		print("   se d>0 introduce un ritardo di d ms dopo ogni linea spedita");
		int port=0;
		
		if (args.length == 0) {
			log("Supply port number in [1025,65535]");
			System.exit(1);
		}
		
		port = Integer.parseInt(args[0]);
		
		if (port < 1024 || port > 65535) {
			log("Invalid port number. Must be in [1025,65535]");
			System.exit(2);
		}
		log("Binding to port "+port);
		
		
		if (args.length > 1) {
			delay = Integer.parseInt(args[1]);
			log("Using a delay of "+delay);
		}
		
		ServerSocket listener = new ServerSocket(port);
		log("MP Server running.");
		
		try {
			while (true) {
				new ServerThread(listener.accept()).start();
			}
		} finally {
			listener.close();
		}
	}

	/************
	 *** A private thread to handle requests on a particular socket. 
	 ************/
	private static class ServerThread extends Thread {
		private Socket socket;
		private final int SO_TIMEOUT_SECS = 30;
		private final String BOOTSTRAP_MESSAGE = "start protocol";

		public ServerThread(Socket socket) {
			this.socket = socket;
			log("New connection at " + socket);

			//Set timeout!
			try {
				this.socket.setSoTimeout(SO_TIMEOUT_SECS*1000);
			}
			catch (Exception e) {
				log("Could not set socket timeout!");
			}

		}

		/**
		 * Services this thread's client
		 **/
		public void run() {
			try {
				// BufferedReader an PrintWriter for I/O on the socket
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

				String line;
				line = in.readLine();
				log("Read from socket: "+line);
				
				int index = -1;
				if (line.equalsIgnoreCase("Einstein")) {
					index = Citazioni.EINSTEIN;
				}
				else if (line.equalsIgnoreCase("Leopardi")) {
					index = Citazioni.LEOPARDI;
				}
				else if (line.equalsIgnoreCase("Manzoni")) {
					index = Citazioni.MANZONI;
				}
				else if (line.equalsIgnoreCase("Neruda")) {
					index = Citazioni.NERUDA;
				}
				else if (line.equalsIgnoreCase("Sordi")) {
					index = Citazioni.SORDI;
				}
				
				String str = "";
				if (index>=0) {
					str = Citazioni.TEXT[index];
					//Simulated delay, milliseconds
					//mysleep(10000);
					log("Sending: "+str);
					out.println(str);
				}
				else {
					send_a_file(line,out);
				}

			} catch (Exception e) {
				log("Generic exception: " + e);
			}
			finally {
				try {
					socket.close();
				} catch (IOException e) {
					log("Couldn't close a socket, what's going on?");
				}
				log("finally: Connection closed");
			}
		}
	}  

		
	private static void send_a_file(String line, PrintWriter out) {
		String filename = "./files/"+line.trim();
		
		File file = new File(filename);
		
		if (file.exists()) {
			int size_bytes = (int) file.length();
			String first_line = ""+size_bytes;
			out.println(first_line);
			log("Sending byte count: "+size_bytes);
			//Send data
			Path f = Paths.get(filename);
			try (InputStream in = Files.newInputStream(f);
			    BufferedReader reader =
			      new BufferedReader(new InputStreamReader(in))) {
			    String data = null;
			    while ((data = reader.readLine()) != null) {
			    	if (delay > 0) mysleep(delay);
			        out.println(data);
			        log("Sending: "+data);
			    }
			} catch (IOException x) {
			    System.err.println(x);
			}
			
		}
	}


	private static void mysleep(long ms) {
		//Simulated delay
		try {
			Thread.sleep(ms);
		}
		catch (Exception e) {
		}
	}



}

package it.unisa.di.mp;

class Citazioni {
	
	static final int EINSTEIN = 0;
    static final int LEOPARDI = 1;
    static final int MANZONI  = 2;
    static final int NERUDA   = 3;
    static final int SORDI    = 4;

    static final String[] TEXT = 
    	{//Einstein
    		"Quando un uomo siede un'ora in compagnia di una bella ragazza, sembra sia passato un minuto."+
    		"Ma fatelo sedere su una stufa per un minuto e gli sembrerà più lungo di qualsiasi ora."+ 
    		"Questa è la relatività.", 
    	//Leopardi
    		"Il più certo modo di celare agli altri i confini del proprio sapere, è di non trapassarli", 
    	//Manzoni
    		"Il buon senso c'era; ma se ne stava nascosto per paura del senso comune.",
    	//Neruda
    		"Il bambino che non gioca più è diventato adulto, ma l\'adulto che non gioca più ha perso"+
    		"per sempre il bambino che aveva dentro di sè.",
    	//Sordi
    		"(Rivolto a un beduino nel mezzo del deserto) Ammazza che spiagge che c'avete!"
    	};    
}
